import React from 'react'

function ComponentTwo() {
    
    return (

        <div>
            <h1>Its Component 2</h1>
        </div>
    )
}

export default ComponentTwo;