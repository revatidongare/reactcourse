import React from 'react'

function ComponentOne() {
    
    return (

        <div>
            <h1>Its Component 1</h1>
        </div>
    )
}

export default ComponentOne;