
import './App.css';
import ComponentOne from './Components/ComponentOne';
import ComponentTwo from './Components/ComponentTwo';


function App() {
  return (
    <div className="App">
    
        <h1>helloooo</h1>
        <ComponentOne />
        <ComponentTwo />
        
    </div>
  );
}

export default App;
