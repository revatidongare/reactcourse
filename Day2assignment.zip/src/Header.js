
import Service from './Service';

function Header(){

    const services=[
        {
            title:"Web Development",
            subtitle:"HTML,CSS,JavaScript",
            desc:"Web development is the work involved in developing a Web site for the Internet or an intranet. Web development can range from developing a simple single static page of plain text to complex web applications, electronic businesses, and social network services.",
            image:"https://5.imimg.com/data5/XX/XH/YP/SELLER-57468739/web-development-company-in-pune-500x500.png"
        },
        {
            title:"App Development",
            subtitle:"React Native, Android,IOS",
            desc:"Mobile app development is the act or process by which a mobile app is developed for mobile devices, such as personal digital assistants, enterprise digital assistants or mobile phones.",
            image:"https://www.digitalauthority.me/wp-content/uploads/2019/04/shutterstock_572886535.jpg"
        },
        {
            title:"Python Development",
            subtitle:"Python",
            desc:"Python is an interpreted high-level general-purpose programming language. Its design philosophy emphasizes code readability with its use of significant indentation. ",
            image:"https://content.techgig.com/photo/80100245/8-steps-to-master-python-programming-for-data-science.jpg?88712"
        },
        {
            title:"Java Development",
            subtitle:"Core Java, Advanced Java",
            desc:"Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.",
            image:"https://content.techgig.com/thumb/msid-82064046,width-860,resizemode-4/Essentials-of-Java-programming-that-every-beginner-should-know.jpg?98482"
        },
        {
            title:"SQL Programming",
            subtitle:"SQL,My-SQL",
            desc:"SQL is a domain-specific language used in programming and designed for managing data held in a relational database management system, or for stream processing in a relational data stream management system.",
            image:"https://www.tahutek.com/wp-content/uploads/2020/03/oracle-java-14.jpg"
        }
    ]


    return (
        <div>
            <h1 style={{marginLeft:"15%"}}> Courses List</h1>
            <div className="container">

                
                {
                    services.map((service,index)=>(

                        <Service key={index} title={service.title} subtitle={service.subtitle} desc={service.desc} image={service.image} />

                    ))
                }
            </div>

        </div>

        
    )

}


export default Header;